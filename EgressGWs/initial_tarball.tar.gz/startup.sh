sudo ifconfig eth1 down
sudo ifconfig eth1 hw ether 76:83:F0:B6:AA:C6
sudo ifconfig eth1 up