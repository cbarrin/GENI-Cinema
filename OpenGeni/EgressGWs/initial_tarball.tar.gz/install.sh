echo "Enter username:"
read USERNAME
echo $USERNAME > /home/$USERNAME/username


sudo apt-get install gcc
sudo apt-get install make
sudo apt-get update

sudo apt-get install vlc -y
sudo apt-get install libavcodec53 -y
sudo apt-get install libavcodec-dev -y
sudo apt-get install libavcodec-extra-53 -y
